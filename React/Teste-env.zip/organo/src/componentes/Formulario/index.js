import './Formulario.css'
import ListaSuspensa from '../ListaSuspensa'
import Botao from '../Botao'

const Formulario = (props) => {

    const times = [
        'Programação',
        'Front-End',
        'Data Science',
        'Devops',
        'UX e Design',
        'Mobile',
        'Inovação e Gestão'
    ]

    const aoSalvar = (evento) => {
        evento.preventDefault()
        console.log('Form foi submetido')
    }


    return (
    <section className="Formulario">
        <form onSubmit={aoSalvar}>
        <h1 className="h1">Preencha os dados para criar o card do colaborador.</h1>
        {props.children}
        <ListaSuspensa label="Time" itens={times}></ListaSuspensa>
        <Botao>
            Criar Card
        </Botao>
        </form>
    </section>
    )
}

export default Formulario