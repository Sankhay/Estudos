import { Banner } from "./Banner";

export default Banner