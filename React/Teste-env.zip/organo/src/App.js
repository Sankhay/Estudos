import Banner from './componentes/Banner';
import CampoTexto from './componentes/CampoTexto';
import Formulario from './componentes/Formulario'

function App() {
  return (
    <div className="App">
      <Banner></Banner>
      <Formulario>
        <CampoTexto obrigatorio={true} label="Nome" placeholder="Digite seu nome"></CampoTexto>
        <CampoTexto obrigatorio={true} label="Cargo" placeholder="Digite seu cargo"></CampoTexto>
        <CampoTexto obrigatorio={true} label="Imagem" placeholder="Digite o endereço da imagem"></CampoTexto>
      </Formulario>
      
    </div>
  );
}

export default App;
