// config.js
const config = {
    ENV_NAME: 'Teste-env',
    // other configuration values...
  };
  export default config;
  